hdfs dfs -mkdir assignment-11 assignment-11/input
hdfs dfs -put path/to/test.txt assignment-11/input
hadoop jar path/to/WordCount.jar WordCount assignment-11/input assignment-11/output
hadoop fs -cat assignment-11/output/*